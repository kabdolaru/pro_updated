var mylinks = document.querySelector(".navigation-links");

document.addEventListener("DOMContentLoaded", function() {
   
    showLoadingSpinner();

 
    setTimeout(hideLoadingSpinner, 2500);
});

function HamburgerMenu() {
    if (mylinks.style.display === "block") {
        mylinks.style.display = "none";
    } else {
        mylinks.style.display = "block";
    }
}




function showLoadingSpinner() {
    document.querySelector('.loading-overlay').style.display = 'block';
}

function hideLoadingSpinner() {
    document.querySelector('.loading-overlay').style.display = 'none';
}
