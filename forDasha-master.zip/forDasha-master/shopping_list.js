document.addEventListener("DOMContentLoaded", function() {
    showLoadingSpinner();
    setTimeout(function() {
        hideLoadingSpinner();
        displayShoppingList();
    }, 2500);
});

function HamburgerMenu() {
    const mylinks = document.querySelector(".navigation-links");
    if (mylinks.style.display === "block") {
        mylinks.style.display = "none";
    } else {
        mylinks.style.display = "block";
    }
}

function showLoadingSpinner() {
    document.querySelector('.loading-overlay').style.display = 'block';
}

function hideLoadingSpinner() {
    document.querySelector('.loading-overlay').style.display = 'none';
}

function displayShoppingList() {
    const shoppingList = JSON.parse(localStorage.getItem('shoppingList'));
    const shoppingItemsList = document.getElementById('shopping-items');
    shoppingItemsList.innerHTML = '';
    if (shoppingList && shoppingList.length > 0) {
        shoppingList.forEach((item, index) => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <span>${item.name} - ${item.price}</span>
                <input type="number" min="1" value="1" id="quantity-${index}">
            `;
            shoppingItemsList.appendChild(listItem);
        });
    } else {
        const listItem = document.createElement('li');
        listItem.textContent = 'Your shopping list is empty';
        shoppingItemsList.appendChild(listItem);
    }
}

function deleteItems() {
    localStorage.removeItem('shoppingList');
    displayShoppingList();
}

const payButton = document.querySelector('.Pay');


payButton.addEventListener('click', () => {

    const modal = document.createElement('div');
    modal.classList.add('modal');

  
    const form = document.createElement('form');
    form.innerHTML = `
        <label for="cardNumber">Card Number:</label>
        <input type="text" id="cardNumber" name="cardNumber" required><br>
        <label for="expirationDate">Expiration Date:</label>
        <input type="text" id="expirationDate" name="expirationDate" required><br>
        <label for="cvv">CVV:</label>
        <input type="text" id="cvv" name="cvv" required><br>
        <button type="submit">Submit</button>
    `;

 
    modal.appendChild(form);

  
    document.body.appendChild(modal);


    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.remove();
        }
    });


    event.preventDefault();
});
